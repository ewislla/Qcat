import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Twitter, MessageCircle } from 'lucide-react';

const JoinClowder: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  return (
    <section
      id="join"
      className="py-20 px-4 relative bg-deep-purple"
      ref={ref}
    >
      <div className="container mx-auto max-w-4xl">
        <motion.div
          className="flex flex-col items-center quantum-card"
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
        >
          <motion.h2
            className="text-3xl font-pixel text-neon-blue mb-8 text-shadow-neon-blue text-center"
            variants={itemVariants}
          >
            JOIN THE CLOWDER
          </motion.h2>

          <motion.div className="text-center mb-8" variants={itemVariants}>
            <p className="text-xl font-retro text-white mb-2">Become a Quantum Pioneer.</p>
            <p className="text-xl font-retro text-white mb-2">Earn Quantum Nip NFTs.</p>
            <p className="text-xl font-retro text-white mb-6">Help fund science with memes.</p>
          </motion.div>

          <motion.div 
            className="flex justify-center space-x-6 mb-8"
            variants={itemVariants}
          >
            <a 
              href="#" 
              className="text-neon-blue hover:text-golden transition-colors"
              aria-label="Twitter"
            >
              <Twitter size={32} className="hover:animate-pulse" />
            </a>
            <a 
              href="#" 
              className="text-neon-blue hover:text-golden transition-colors"
              aria-label="Discord"
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                width="32" 
                height="32" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                className="hover:animate-pulse"
              >
                <circle cx="9" cy="12" r="1"></circle>
                <circle cx="15" cy="12" r="1"></circle>
                <path d="M7.5 7.5c3.5-1 5.5-1 9 0"></path>
                <path d="M7 16.5c3.5 1 6.5 1 10 0"></path>
                <path d="M15.5 17c0 1 1.5 3 2 3 1.5 0 2.833-1.667 3.5-3 .667-1.667.5-5.833-1.5-11.5-1.457-1.015-3-1.34-4.5-1.5l-1 2.5"></path>
                <path d="M8.5 17c0 1-1.356 3-1.832 3-1.429 0-2.698-1.667-3.333-3-.635-1.667-.48-5.833 1.428-11.5C6.151 4.485 7.545 4.16 9 4l1 2.5"></path>
              </svg>
            </a>
            <a 
              href="#" 
              className="text-neon-blue hover:text-golden transition-colors"
              aria-label="Telegram"
            >
              <MessageCircle size={32} className="hover:animate-pulse" />
            </a>
          </motion.div>

          <motion.button
            className="cosmic-button group relative overflow-hidden"
            variants={itemVariants}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <span className="relative z-10">Join the Clowder</span>
            <span className="absolute inset-0 bg-gradient-to-r from-cosmic-purple to-neon-blue opacity-0 group-hover:opacity-100 transition-opacity duration-300"></span>
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};

export default JoinClowder;